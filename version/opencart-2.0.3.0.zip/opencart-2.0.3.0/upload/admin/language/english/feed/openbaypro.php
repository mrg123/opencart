<?php
// Heading
$_['heading_title']	  = 'OpenBay Pro';

// Text
$_['text_module']    = 'Modules';
$_['text_installed'] = 'OpenBay Pro module is now installed. It is available under Extensions -> OpenBay Pro';