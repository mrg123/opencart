<?php 
$_['heading_title']                     = 'eBay';
$_['text_edit']                         = 'Edit';
$_['text_install']                      = 'Install';
$_['text_uninstall']                    = 'Uninstall';
$_['text_enabled']                      = 'Enabled';
$_['text_disabled']                     = 'Disabled';
$_['error_category_nosuggestions']      = 'Could not load any suggested categories';
$_['lang_text_success']                 = 'You have saved your changes to the eBay extension';