<?php

// Heading
$_['heading_title']    = '商店切换';

// Text
$_['text_module']      = '模组';
$_['text_success']     = '成功: 已修改商店切换模组！';
$_['text_edit']        = '编辑商店切换模组';

// Entry
$_['entry_admin']      = '仅适用管理用户';
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 无权限修改商店切换模组！';