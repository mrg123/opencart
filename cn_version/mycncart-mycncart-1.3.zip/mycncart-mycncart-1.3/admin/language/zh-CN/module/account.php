<?php

// Heading
$_['heading_title']    = '会员账户';

$_['text_module']      = '模组';
$_['text_success']     = '成功: 已修改会员账户模组！';
$_['text_edit']        = '编辑会员账户模组';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 无权限修改会员账户模组！';