<?php

// Text
$_['text_footer'] 	= '<a href="http://www.mycncart.com">MyCnCart</a> &copy; 2015-' . date('Y') . ' 版权所有。<a>';
$_['text_version'] 	= '版本号 %s';
