<?php

// Heading
$_['heading_title']        = 'MyCnCart China';

// Text
$_['text_order']           = '订单';
$_['text_order_status']    = '处理中';
$_['text_complete_status'] = '已完成';
$_['text_customer']        = '会员';
$_['text_online']          = '在线会员';
$_['text_approval']        = '挂起等待确认';
$_['text_product']         = '商品';
$_['text_stock']           = '库存不足';
$_['text_review']          = '评论';
$_['text_return']          = '退货';
$_['text_affiliate']       = '加盟';
$_['text_store']           = '商店';
$_['text_front']           = '商店前台';
$_['text_help']            = '帮助';
$_['text_homepage']        = '首页';
$_['text_support']         = '支持论坛';
$_['text_documentation']   = '文档';
$_['text_logout']          = '安全退出';