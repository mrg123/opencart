<?php

// Text
$_['text_subject']  = '%s - 密码重置请求';
$_['text_greeting'] = '管理员 %s 请求新的密码。';
$_['text_change']   = '点击如下链接重置您的密码:';
$_['text_ip']       = '发起本请求的IP地址为: %s';