<?php
// Heading
$_['heading_title']    = '分析';

// Text
$_['text_success']     = '成功: 已修改分析！';
$_['text_list']        = '分析列表';

// Column
$_['column_name']      = '分析名称';
$_['column_status']    = '状态';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 无权限修改分析！';
