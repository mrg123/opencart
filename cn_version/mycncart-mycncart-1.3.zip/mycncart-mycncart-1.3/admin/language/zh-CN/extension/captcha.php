<?php
// Heading
$_['heading_title']    = '验证码';

// Text
$_['text_success']     = '成功: 已修改验证码！';
$_['text_list']        = '验证码列表';

// Column
$_['column_name']      = '验证码名称';
$_['column_status']    = '状态';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 无权修改验证码！';
