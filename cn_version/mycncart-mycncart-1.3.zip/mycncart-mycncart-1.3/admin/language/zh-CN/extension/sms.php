<?php

// Heading
$_['heading_title']     = '短信验证';

// Text
$_['text_success']      = '成功: 已修改短信验证！';
$_['text_list']         = '短信验证列表';

// Column
$_['column_name']       = '短信验证';
$_['column_status']     = '状态';
$_['column_sort_order'] = '排序';
$_['column_action']     = '操作';

// Error
$_['error_permission']  = '警告: 无权限修改短信验证！';