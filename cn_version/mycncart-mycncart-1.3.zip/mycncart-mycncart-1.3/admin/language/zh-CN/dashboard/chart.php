<?php

// Heading
$_['heading_title'] = '销售分析';

// Text
$_['text_order']    = '订单';
$_['text_customer'] = '会员';
$_['text_day']      = '今天';
$_['text_week']     = '周';
$_['text_month']    = '月';
$_['text_year']     = '年';