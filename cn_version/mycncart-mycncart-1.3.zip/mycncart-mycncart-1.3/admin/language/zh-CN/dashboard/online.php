<?php

// Heading
$_['heading_title'] = '在线人数';

// Text
$_['text_view']     = '查看更多......';