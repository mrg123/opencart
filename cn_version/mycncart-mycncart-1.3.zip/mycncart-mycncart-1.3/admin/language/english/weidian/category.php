<?php

// Heading
$_['heading_title']          = '微店分类管理';

// Text
$_['text_success']           = '成功: 已经修改微店分类！';
$_['text_list']              = '微店分类列表';
$_['text_default']           = '默认';
$_['text_success']           = '成功推送或更新分类到微店';
$_['text_delete_success']    = '成功取消该微店分类';
$_['text_warning']           = '出现问题，请检查微店参数设置是否正确，以及该分类是否已经存在于微店。';

// Column
$_['column_name']            = '微店分类名称';
$_['column_sort_order']      = '排序';
$_['column_action']          = '操作';



