<?php
$_['heading_title']    = 'BaiDu Analytics';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified BaiDu Analytics!';
$_['text_signup']      = 'Login to your <a href="http://www.baidu.com/analytics/" target="_blank"><u>BaiDu Analytics</u></a> account and after creating your website profile copy and paste the analytics code into this field.';
$_['text_default']     = 'Default';

// Entry
$_['entry_code']       = 'BaiDu Analytics Code';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify BaiDu Analytics!';
$_['error_code']	   = 'Code required!';
