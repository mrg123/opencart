<?php
// Heading
$_['heading_title']    = 'Blog Search';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified blog search module!';
$_['text_edit']        = 'Edit Blog Search Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify blog search module!';